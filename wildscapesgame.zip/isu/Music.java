package isu;

import java.io.*;
import java.net.URL;
import javax.sound.sampled.*;

public class Music {
    Clip clip;
    Clip clip2;
    URL[] soundURL = new URL[6];
    public Music(){
        soundURL[0] = getClass().getResource("/isu/music/music (1).wav"); //Music
        soundURL[1] = getClass().getResource("/isu/music/star.wav"); //Coin sound
        soundURL[2] = getClass().getResource("/isu/music/deathplayer.wav"); //Death sound
        soundURL[3] = getClass().getResource("/isu/music/ouch.wav"); //Ouch
        soundURL[4] = getClass().getResource("/isu/music/victory.wav"); //Victory sound
        soundURL[5] = getClass().getResource("/isu/music/evillaugh.wav"); //Evil sound

    }
    public void setFile(int i){
        try{
            AudioInputStream as = AudioSystem.getAudioInputStream(soundURL[i]);
            clip = AudioSystem.getClip();
            clip.open(as);
        } catch (IOException e){
            System.out.println("IO ERROR");
        } catch (UnsupportedAudioFileException e){
            System.out.println("UNSUPPORTED FILE");
        } catch (LineUnavailableException e){
            System.out.println("LINE UNAVAILABLE");
        }
    }
    public void setMusicFile(int i){
        try{
            AudioInputStream as = AudioSystem.getAudioInputStream(soundURL[i]);
            clip2 = AudioSystem.getClip();
            clip2.open(as);
        } catch (IOException e){
            System.out.println("IO ERROR");
        } catch (UnsupportedAudioFileException e){
            System.out.println("UNSUPPORTED FILE");
        } catch (LineUnavailableException e){
            System.out.println("LINE UNAVAILABLE");
        }
    }
    public void play(){
        clip.start();
    }
    public void playEffect(){
        clip2.start();
    }
    public void loop(){
        clip.loop(Clip.LOOP_CONTINUOUSLY);
    }
    public void stop(){
        clip.stop();
    }
}