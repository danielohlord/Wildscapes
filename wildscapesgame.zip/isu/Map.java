package isu;

import javax.swing.ImageIcon;
import java.io.*;

public class Map {
    int [] endPortalLocation = {1750,1750,1750,1750,1750};
    ImageIcon portal = new ImageIcon(getClass().getResource("/isu/other/portal.gif"));
    ImageIcon logo = new ImageIcon(getClass().getResource("/isu/other/wildscapeslogo.png"));
    ImageIcon[] background = {new ImageIcon(getClass().getResource("/isu/other/clouds.png")), new ImageIcon(getClass().getResource("/isu/other/blackbrick.png")),
            new ImageIcon(getClass().getResource("/isu/other/winter.png")), new ImageIcon(getClass().getResource("/isu/other/lavaspike.png")), new ImageIcon(getClass().getResource("/isu/other/cave.png"))};
    ImageIcon controlScreen = new ImageIcon(getClass().getResource("/isu/other/controlScreen.png"));
    ImageIcon menuScreen = new ImageIcon(getClass().getResource("/isu/other/menu.png"));
    ImageIcon levelScreen = new ImageIcon(getClass().getResource("/isu/other/level.png")); //Use temporary image, some levels locked
    ImageIcon levelCompletedScreen = new ImageIcon(getClass().getResource("/isu/other/levelcompleted.png"));
    ImageIcon levelFailedScreen = new ImageIcon(getClass().getResource("/isu/other/levelfailed.png"));

    int[][][] levels = new int[5][37][156];


    public void getMapData(){
        try{
            for (int i = 0; i < levels.length; i++){
                String line;
                BufferedReader br = new BufferedReader(new FileReader("./src/isu/map/level"+(i+1)+".txt"));
                int count = 0;
                while ((line = br.readLine()) != null){
                    String[] numbers = line.split(",");
                    for (int j = 0; j < numbers.length; j++){
                        levels[i][count][j] = Integer.parseInt(numbers[j]);
                    }
                    count++;
                } br.close();
            }
        } catch (FileNotFoundException e){
            System.out.println("NO FILE");
        }catch (IOException e){
            System.out.println("ERROR");
        }
    }
} //Base length 23