package isu;
import java.io.*;

public class SaveGame {
    String fileName = "./src/isu/userData/user.data";
    int [] storeScore = null;
    int stars = 0;
    int grandStars = 0;
    int difficulty = 0;
    boolean musicEnabled = false;
    boolean colliderEnabled = false;

    public int setup(){
        File dir1 = new File("./src/isu/userData"); //Create directories
        dir1.mkdir(); //Still creates if somehow the directories are gone
        try{
            File file = new File(fileName);
            if (file.createNewFile()){
                writeDefaultData();
            }
        } catch (IOException e){
            return -1;
        }
        return 0;
    }
    public void writeDefaultData(){
        try{
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(fileName)));
            out.writeInt(5);
            for (int i = 0; i < 5; i++){
                out.writeInt(100000);
            }
            out.writeInt(0);
            out.writeInt(0);
            out.writeInt(0);
            out.writeBoolean(true);
            out.writeBoolean(false);
            out.close();

        } catch (FileNotFoundException e){
            System.out.println("DEFAULT: File Not Found");
        } catch (IOException e){
            System.out.println("DEFAULT: IO ERROR");
        }
    }
    public void readSavedGame(){
        try{
            DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(fileName)));
            storeScore = new int[in.readInt()];

            for (int i = 0; i < storeScore.length; i++){
                storeScore[i] = in.readInt();
            }
            stars = in.readInt();
            grandStars = in.readInt();
            difficulty = in.readInt();
            musicEnabled = in.readBoolean();
            colliderEnabled = in.readBoolean();
            in.close();
        } catch (FileNotFoundException e){
            System.out.println("READ: File Not Found");
        } catch (IOException e){
            System.out.println("READ: IO ERROR");
        }
    }
    public void saveGame(){
        try{
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(fileName)));
            out.writeInt(storeScore.length);
            for (int i : storeScore){
                out.writeInt(i);
            }
            out.writeInt(stars);
            out.writeInt(grandStars);
            out.writeInt(difficulty);
            out.writeBoolean(musicEnabled);
            out.writeBoolean(colliderEnabled);
            out.close();

        } catch (IOException e){
            System.out.println("WRITE: IO ERROR");
        }
    }
}