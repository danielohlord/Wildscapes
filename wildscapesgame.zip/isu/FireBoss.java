package isu;

import javax.swing.ImageIcon;
import java.awt.Rectangle;

public class FireBoss {

    int x = -500;
    int y = 75;

    protected ImageIcon fireBoss = new ImageIcon(getClass().getResource("/isu/other/firemonster.png"));
    public Rectangle getBounds(int offset){
        return new Rectangle(x+offset, y, 400,400);
    }
}
