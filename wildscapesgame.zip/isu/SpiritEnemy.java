package isu;

import javax.swing.ImageIcon;
import java.awt.Rectangle;

public class SpiritEnemy {
    ImageIcon greenSpirit = new ImageIcon(getClass().getResource("/isu/other/greenspirit.gif"));
    ImageIcon iceSpirit = new ImageIcon(getClass().getResource("/isu/other/icespirit.gif"));
    ImageIcon fireSpirit = new ImageIcon(getClass().getResource("/isu/other/firespirit.gif"));

    static int[][] resetSpiritXLocation = {{0,0,0,0,0},{560,1640,730,1125,906},{288,650,1206,1190,1629},{1227,819,350,1040,490},{291,222,1059,1416,1605}};
    static int[][] resetSpiritYLocation = {{0,0,0,0,0},{188,380,380,380,107},{379,124,-37,235,381},{235,381,43,60,380},{93,412,76,364,91}};

    int x = 0;
    int y = 0;

    public Rectangle getBounds(int offset){
        return new Rectangle(x+offset, y, 64,64);
    }
    public void resetSpiritLocation(int level, int i){
        x = resetSpiritXLocation[level-1][i];
        y = resetSpiritYLocation[level-1][i];
    }
}