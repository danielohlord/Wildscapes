package isu;
import javax.swing.ImageIcon;

public class Coin {
    ImageIcon star = new ImageIcon(getClass().getResource("/isu/other/star.png"));
    protected int[][] xCoinData = {{910,1196,1175,865,1622},{1265,822,300,645,1040},{360,909,1154,1240,1520},{270,810,980,1287,1740},{225,633,996,1479,1720}};
    protected int[][] yCoinData = {{80,222,16,254,254},{500,110,50,380,380},{379,124,-37,235,12},{43,140,510,235,25},{93,396,76,364,200}};
}
