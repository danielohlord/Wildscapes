package isu;

import javax.swing.ImageIcon;

public class Asset {
    protected ImageIcon[] playerAnim = new ImageIcon[12];
    protected ImageIcon[] tiles = new ImageIcon[173];

    protected void resetAttackGif(){
        playerAnim[8] = new ImageIcon(getClass().getResource("/isu/player/player (8).gif"));
    }
    protected void getPlayerIcon(){
        for (int i = 0; i < playerAnim.length; i++){ //Store all imageIcon player in the array. The Game constructor will call this method
            playerAnim[i] = new ImageIcon(getClass().getResource("/isu/player/player (" +i+").gif"));
        }
    }
    protected void getTiles(){
        for (int i = 0; i < tiles.length; i++){ //Store all imageIcon tiles in the array. The Game constructor will call this method
            tiles[i] = new ImageIcon(getClass().getResource("/isu/tiles/tiles (" +i+").png"));
        }
    }
}