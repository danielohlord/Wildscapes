package isu;

import javax.swing.ImageIcon;

public class Settings {
    ImageIcon settingsPanel = new ImageIcon(getClass().getResource("/isu/other/settings.png"));
    ImageIcon difficultySwitchEasy = new ImageIcon(getClass().getResource("/isu/other/easysign.png"));
    ImageIcon difficultySwitchHard = new ImageIcon(getClass().getResource("/isu/other/hardsign.png"));
    ImageIcon onSwitch = new ImageIcon(getClass().getResource("/isu/other/onsign.png"));
    ImageIcon offSwitch = new ImageIcon(getClass().getResource("/isu/other/offsign.png"));

    public ImageIcon difficulty(int difficulty){
        if (difficulty == 0){
            return difficultySwitchEasy;
        } else
            return difficultySwitchHard;
    }
    public ImageIcon musicEnabled(boolean musicEnabled){
        if (musicEnabled){
            return onSwitch;
        } else
            return offSwitch;
    }
    public ImageIcon showCollider(boolean colliderEnabled){
        if (colliderEnabled){
            return onSwitch;
        } else
            return offSwitch;
    }
}
