/*
 * Wildscapes
 */
package isu;

import javax.swing.JFrame; //Swing imports
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.Timer;

import java.awt.Graphics; //Awt imports
import java.awt.Color;
import java.awt.Rectangle;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.Font;

import java.util.Arrays; //Scanner and arrays
import java.util.Scanner;

public class Game extends JPanel implements ActionListener, KeyListener {

    Timer timer = new Timer(2, this);//Timer

    int x = 53, y = 300, xVel,leftXVel, rightXVel, jumpVel, speed = 3, offset, attackOffset, cooldown; //Player location & speed & jump
    int tileIndex = 0; //Index for tiles
    int previousKey = 0;
    int shiftMap = 320; //Shift map to accommodate the water (Barriers)
    int level = 1; //Level
    int fireBossX = -540, fireBossSpeed = 1;
    int starAmt, grandStarAmt, heartAmt = 3, score, difficulty;

    int[] xCoinLocation = new int[5];
    int[] yCoinLocation = new int[5];
    int[] storeScore = new int[5];

    ImageIcon heart = new ImageIcon(getClass().getResource("/isu/other/heart.png"));
    ImageIcon exitLogo = new ImageIcon(getClass().getResource("/isu/other/xlogo.png"));

    boolean hasDownCollided, hasLeftCollided, hasRightCollided, hasTopCollided; //Collision variables
    boolean leftPressed, rightPressed, upPressed, groundTouched, jumpPressed, isAttacking, resetScreen, enemyHit;
    static boolean gameEnabled, menuScreen, levelScreen, settingsScreen,levelCompleted, levelFailed, musicEnabled, colliderEnabled;

    Asset assets = new Asset();
    Map map = new Map(); //Get map info
    Music music = new Music();
    Coin coin = new Coin();
    Settings settings = new Settings();
    SaveGame saveGame = new SaveGame();
    SpiritEnemy[] spirits = new SpiritEnemy[5];
    FireBoss fireboss = new FireBoss();

    public Game(){
        for (int i = 0; i < spirits.length; i++) {
            spirits[i] = new SpiritEnemy();
        }
        addKeyListener(this); //Key listener
        setFocusable(true); //Set focus
        setFocusTraversalKeysEnabled(false);

        saveGame.setup(); //Get user's saved game
        saveGame.readSavedGame();
        setSavedVariables();

        assets.getPlayerIcon(); //Get player anim and tiles
        assets.getTiles(); //Load tiles

        map.getMapData(); //Get map data, load map from txt file
        resetVariables(); //Reset variables

        setSavedVariables();
        if (musicEnabled){ //Only play music if the user enables it
            playMusic(0);
        }
        System.out.println(map.levels[0].length);
        System.out.println(map.levels[0][23].length);
        timer.start(); //Start timer
    }
    public void setSavedVariables(){
        starAmt = saveGame.stars;
        grandStarAmt = saveGame.grandStars;
        storeScore = saveGame.storeScore;
        difficulty = saveGame.difficulty;
        musicEnabled = saveGame.musicEnabled;
        colliderEnabled = saveGame.colliderEnabled;
    }
    public static void main(String[] args) {
        Game panel = new Game(); //Get panel and window
        JFrame window = new JFrame();

        window.setTitle("Wildscapes"); //Title
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //Shut down on exit
        window.add(panel); //Add the panel
        window.pack(); //Pack

        window.setResizable(false); //Do not allow resizing. I made the game for that specific resolution
        window.setSize(900,600); //Size
        window.setLocationRelativeTo(null); //Centre the screen
        window.setVisible(true); //Make it not invisible
        panel.requestFocus(); //Get foucs
        panel.setBackground(Color.CYAN);
        menuScreen = true;
    }
    public void paintComponent(Graphics g){
        super.paintComponent(g);

        g.setFont(new Font("Arial", Font.BOLD, 35));

        if (menuScreen){//Menu screen
            paintMenuScreen(g);
        } else if (levelScreen){ //Level selection Screen
            paintLevelScreen(g);
        } else if (gameEnabled){ //Game screen
            paintGame(g);
        }
    }
    public void paintMenuScreen(Graphics g){
        map.menuScreen.paintIcon(this, g, 0, 0);
        levelCompleted = false; levelFailed = false;
        if (settingsScreen){
            settings.settingsPanel.paintIcon(this, g, 150, 50);
            g.setColor(Color.BLACK);
            g.drawString(Integer.toString(starAmt), 320, 365);
            g.drawString(Integer.toString(grandStarAmt), 620, 365);
            settings.difficulty(difficulty).paintIcon(this, g, 500, 155);
            settings.musicEnabled(musicEnabled).paintIcon(this, g, 500, 195);
            settings.showCollider(colliderEnabled).paintIcon(this, g, 500, 235);
            exitLogo.paintIcon(this, g, 750, 20);
        }
    }
    public void paintLevelScreen(Graphics g){
        map.levelScreen.paintIcon(this, g, 0, 0);
    }
    public void paintGame(Graphics g){
        map.background[level-1].paintIcon(this, g, 0,0);
        if (level < 2){ //Paint control screen, only for level 1
            map.controlScreen.paintIcon(this, g, 80+offset, 150);
        }
        for (int i = 0; i < map.levels[level-1].length; i++){
            for (int j = 0; j < map.levels[level-1][i].length; j++){
                assets.tiles[map.levels[level-1][i][j]].paintIcon(this, g, (j*16)+offset-shiftMap, i*16); //Draw tile
            }
        }
        for (int i = 0; i < xCoinLocation.length; i++){
            coin.star.paintIcon(this, g, xCoinLocation[i]+offset, yCoinLocation[i]);
        }
        g.setColor(Color.RED);

        if (level < 2){ //Only paint logo if it is level 1
            map.logo.paintIcon(this, g, 50+offset, -25);
        }
        map.portal.paintIcon(this, g, 140+offset, 350); //First Portal
        map.portal.paintIcon(this, g, map.endPortalLocation[level-1]+offset, 350); // End Portal
        assets.playerAnim[tileIndex].paintIcon(this, g, x, y); //Draw character

        paintEnemies(g); //Paint enemies;

        if (colliderEnabled){
            paintCollider(g);
        }

        g.setColor(Color.BLACK);
        heart.paintIcon(this, g, 740, 0); //Draw heart image
        g.drawString(Integer.toString(heartAmt), 762, 43); //Heart amt numerical (TEXT)
        exitLogo.paintIcon(this, g, 810 ,0);

        if (level == 2 || level == 4){
            g.setColor(Color.WHITE);
        }
        g.drawString("Time: "+score, 100, 35); //Display score
        g.drawString("Best Time: "+storeScore[level-1], 400, 35); //Display score

        g.setColor(Color.BLACK);
        if (levelCompleted){
            map.levelCompletedScreen.paintIcon(this, g, 200, 100);
            uploadSavedData();
            g.drawString("Time: "+score, 275, 325);
        } else if (levelFailed){
            map.levelFailedScreen.paintIcon(this, g, 200, 100);
            fireBossSpeed = 0; fireBossX = -540;
            uploadSavedData();
        }
    }
    public void paintCollider(Graphics g){
        g.fillRect(0, 800, 1000, 25);
        g.drawRect(x+94, y+130, 40,10);
        g.drawRect(x+89, y+65, 7,65);
        g.drawRect(x+134, y+65, 7,65);
        g.drawRect(x+94, y+60, 40,10);
        g.drawRect(x+94,y+140,40,10);
        g.drawRect(x+94,y+50,40,10);
        g.drawRect(x+96,y+90,40,40);
        g.setColor(Color.cyan);
        g.drawRect(x+130+attackOffset,y+65,65,65);
        g.drawRect(map.endPortalLocation[level-1]+offset, 350, 45, 90);
        for (int i = 0; i < spirits.length; i++){
            g.drawRect(SpiritEnemy.resetSpiritXLocation[level-1][i]+offset, SpiritEnemy.resetSpiritYLocation[level-1][i], 64, 64);
        }
        for (int i = 0; i < xCoinLocation.length; i++){
            g.drawRect(xCoinLocation[i]+offset, yCoinLocation[i], 64, 64);
        }
        if (level == 5){
            g.drawRect((fireBossX)+offset,75, 400, 400);
        }
    }
    public void paintEnemies(Graphics g){
        if (level == 2){
            for (SpiritEnemy spirit : spirits) {
                spirit.greenSpirit.paintIcon(this, g, spirit.x + offset, spirit.y);
            }
        } else if (level == 3){
            for (SpiritEnemy spirit : spirits) {
                spirit.iceSpirit.paintIcon(this, g, spirit.x + offset, spirit.y);
            }
        } else if (level == 4 || level == 5){
            for (SpiritEnemy spirit : spirits) {
                spirit.fireSpirit.paintIcon(this, g, spirit.x + offset, spirit.y);
            }
        }
        if (level == 5){
            fireboss.fireBoss.paintIcon(this, g, (fireBossX += fireBossSpeed)+offset, 75);
            fireboss.x = fireBossX;
        }
    }
    public void actionPerformed(ActionEvent e){
        if (!levelCompleted && gameEnabled && !levelFailed){
            score++; //Increment score,     Lower the better!
        }
        if (cooldown > 0){
            cooldown--;
        }

        y-=jumpVel; //Jump

        if (gameEnabled && !levelFailed){
            health(); //Check health
            falling(); //Gravity and physics
            sideScrolling(); //Side scrolling
            collision(); //Check for collision
        }
        //System.out.println(x-offset+73 + "  " + (y+70));
        //.out.println(levelFailed);
        //System.out.println("LEFT: "+leftPressed + " RIGHT: "+ rightPressed);
        //System.out.println(x1);
        //System.out.println("ENEMYHIT: "+enemyHit+" ATTACKING: "+ isAttacking + "COOLDOWN: "+cooldown);
        //System.out.println(level);
        //System.out.println(Arrays.deepToString());
        //System.out.println(musicEnabled);
        //System.out.println(difficulty);
        //System.out.println(starAmt);
        //System.out.println(storeScore[0]);
        repaint(); //Repaint
    }
    public void falling(){
        if (rightPressed && jumpVel < 0){
            tileIndex = 6; //RIGHT FALL
        } else if (leftPressed && jumpVel < 0){
            tileIndex = 7; //LEFT FALL
        } else if (jumpVel == 0){
            if (rightPressed){ //Fixes bug when off a platform, falling animation keeps playing when on ground
                tileIndex = 2; //RIGHT RUN
            } else if (leftPressed){
                tileIndex = 3; //LEFT RUN
            }
        } else if (previousKey == 0 && jumpVel < 0){ //Default falling animation, RIGHT
            tileIndex = 6;
        } else if (previousKey == 1 && jumpVel < 0){
            tileIndex = 7;
        }
        if (jumpVel > -13){ //JUMP, DECREASE SPEED, and increase DOWNSPEED (Gravity)
            jumpVel--;
        }
    }
    public void attack(){
        if (leftPressed){
            tileIndex = 9;
        } else if (rightPressed){
            tileIndex = 8;
        } else if (previousKey == 0){
            tileIndex = 8;
        } else if (previousKey == 1){
            tileIndex = 9;
        }
    }
    public void sideScrolling(){
        if (leftPressed && x >= 140){
            x+=leftXVel;
        } else if (x >= 521 && !hasRightCollided){ //Side scrolling RIGHT
            if (rightPressed){ //Has right collided fixes bug player going through wall while side scrolling
                offset -=3; //Just change offset
            }
        } else if (rightPressed && x < 521){ //Side Scrolling LEFT
            x+=rightXVel;
        } else if (x <= 140 && !hasLeftCollided){ //Has left collided fixes bug player going through wall while side scrolling
            if (leftPressed){
                offset += 3; //Just change offset
            }
        }
    }
    public void health(){
        if (heartAmt <= 0 || (y > 600 && y < 1000)){
            y = 1000;
            levelFailed = true;
            xVel = 0; jumpVel = 0; leftXVel = 0; rightXVel = 0;
            heartAmt = 0;
            soundEffect(2);
        }
    }
    public void coin(){
        for (int i = 0; i < 5; i++){
            xCoinLocation[i] = coin.xCoinData[level-1][i];
            yCoinLocation[i] = coin.yCoinData[level-1][i];
        }
    }
    public void playMusic(int i){
        music.setFile(i);
        music.play();
        music.loop();
    }
    public void stopMusic(){
        music.stop();
    }
    public void soundEffect(int i){
        music.setMusicFile(i);
        music.playEffect();
    }
    public void collision(){
        Rectangle playerBoxBottom = new Rectangle(x+94,y+130,40,10); //X & Y moves the box collider according to player movement
        Rectangle playerBoxLeft = new Rectangle(x+89,y+65,7,70); //Offset x and y place the collider correctly
        Rectangle playerBoxRight = new Rectangle(x+134,y+65,7,70);
        Rectangle playerBoxTop = new Rectangle(x+94,y+60,40,10);
        Rectangle playerBottomSecondary = new Rectangle(x+94,y+140,40,10);
        Rectangle playerTopSecondary = new Rectangle(x+94,y+50,40,10);
        Rectangle playerCentre = new Rectangle(x+96,y+90,40,40);
        Rectangle endPortalDetector = new Rectangle(map.endPortalLocation[level-1]+offset, 350, 45, 90);
        Rectangle attackingRectangle = new Rectangle(x+130+attackOffset,y+65,65,65);

        if (playerCentre.intersects(endPortalDetector)){
            soundEffect(4);
            if (level == 5){
                grandStarAmt++;
            }
            y = 1000;
            levelCompleted = true;
        }
        for (int i = 0; i < xCoinLocation.length; i++){
            Rectangle coinCollider = new Rectangle(xCoinLocation[i]+offset, yCoinLocation[i], 64,64);
            if (coinCollider.intersects(playerCentre)){ //Coin detection//Move the coin where the player will not see it.
                yCoinLocation[i] = -1000;
                score -= 500;
                soundEffect(1); //Try making 2 different class files to hand;e the bug
                starAmt++;
            }
        }
        for (int i = 0; i < map.levels[level-1].length; i++){ //Tile collision with player
            for (int j = 0; j < map.levels[level-1][i].length; j++){
                if (map.levels[level-1][i][j] > 0){
                    Rectangle groundCollision = new Rectangle((j*16)+offset-shiftMap, i*16, 16,16);
                    if (level > 1){
                        enemyCollision(playerCentre, attackingRectangle); //Check for enemy collision
                    }
                    if (map.levels[level-1][i][j] > 171){
                        if (playerBoxBottom.intersects(groundCollision)){ //Check if the user touches something toxic, kill player
                            heartAmt = 0;
                            checkRespondCollision(groundCollision,playerBoxBottom,playerBoxLeft,playerBoxRight, playerBoxTop, playerBottomSecondary, playerTopSecondary);
                        }
                    } else
                        checkRespondCollision(groundCollision,playerBoxBottom,playerBoxLeft,playerBoxRight, playerBoxTop, playerBottomSecondary, playerTopSecondary);
                }
            }
        }
    }
    public void enemyCollision(Rectangle playerCentre, Rectangle attackingRectangle){
        for (int i = 0; i < 5; i++){
            Rectangle enemyCollider = spirits[i].getBounds(offset);
            if (enemyCollider.intersects(playerCentre)){
                spirits[i].y = 1000;
                heartAmt--;
                if (heartAmt != 0){
                    soundEffect(3);
                }
            } else if (enemyCollider.intersects(attackingRectangle) && !enemyHit && isAttacking && cooldown <= 0){
                spirits[i].y = 1000;
                enemyHit = true;
            }
        }
        if (level == 5 && !levelFailed){
            Rectangle bossCollider = fireboss.getBounds(offset);
            if (bossCollider.intersects(playerCentre)){
                heartAmt = 0;
            }
        }
    }
    public void checkRespondCollision(Rectangle groundCollision,Rectangle playerBoxBottom, Rectangle playerBoxLeft, Rectangle playerBoxRight, Rectangle playerBoxTop, Rectangle playerBottomSecondary, Rectangle playerTopSecondary){

        if (playerBottomSecondary.intersects(groundCollision)){ //Slow down the velocity if the player is in proximity with the ground, not noticable
            jumpVel = -3;
        }
        if (playerBoxLeft.intersects(groundCollision)){
            leftXVel = 0;
            hasLeftCollided = true;
        }
        if (playerBoxRight.intersects(groundCollision)){
            rightXVel = 0;
            hasRightCollided = true;
        }
        if (playerBoxBottom.intersects(groundCollision)){
            jumpVel = 0;
            jumpPressed = false;
            if (previousKey == 0 && !hasDownCollided && !rightPressed){
                tileIndex = 0;
            } else if (previousKey == 1 && !hasDownCollided && !leftPressed){
                tileIndex = 1;
            } else if (rightPressed && !hasDownCollided){
                tileIndex = 2;
            } else if (leftPressed && !hasDownCollided){
                tileIndex = 3;
            } else if (!hasDownCollided){
                tileIndex = 0;
            }
            hasDownCollided = true;
            groundTouched = true;
        }
        if (playerBoxTop.intersects(groundCollision)){
            hasTopCollided = true;
        }
        if (playerTopSecondary.intersects(groundCollision)){
            jumpVel = -5;
        }
    }
    public void keyPressed(KeyEvent e){
        int c = e.getKeyCode();

        if (c == KeyEvent.VK_1 && levelScreen){level = 1; coin(); resetVariables(); goToGame();} //Configure the levels (1-6)
        else if (c == KeyEvent.VK_2 && levelScreen){level = 2; coin(); resetVariables(); goToGame();}
        else if (c == KeyEvent.VK_3 && levelScreen){level = 3; coin(); resetVariables(); goToGame();}
        else if (c == KeyEvent.VK_4 && levelScreen){ level = 4; coin(); resetVariables(); goToGame();}
        else if (c == KeyEvent.VK_5 && levelScreen){
            level = 5;
            coin(); resetVariables(); goToGame();
            if (musicEnabled){
                stopMusic();
                playMusic(5);
            }
        }

        if (c == KeyEvent.VK_ENTER && gameEnabled){
            if (levelCompleted){
                resetVariables(); //This needs to be called twice
                if (level == 5 && musicEnabled){
                    stopMusic();
                    playMusic(0);
                }
                if (level == 5){
                    resetVariables();
                    menuScreen = true;
                    gameEnabled = false;
                } else{
                    level++;
                    levelCompleted = false;
                    resetVariables();
                    coin();
                    if (level > 4 && musicEnabled){
                        stopMusic();
                        playMusic(5);
                    }
                }
            } else if (levelFailed){
                resetVariables();
                score = 0;
                levelFailed = false;
                coin();
            }
        } else if (c == KeyEvent.VK_RIGHT && !hasRightCollided && !levelCompleted && !levelFailed && !settingsScreen){ //Right movement, only move if not collided
            if (menuScreen){
                levelScreen = true;
                menuScreen = false;
            } else if (gameEnabled){
                rightXVel = speed;
                previousKey = 0;
                attackOffset = 0;

                if (jumpVel == 0){
                    tileIndex = 2;
                }
                rightPressed = true; //Right pressed, others false
                leftPressed = false;
                upPressed = false;
            }
        } else if (c == KeyEvent.VK_LEFT && !hasLeftCollided && !levelCompleted && !levelFailed){ //Left movement, only move if not collided
            if (menuScreen){ //Left key is also used in the menu screen
                settingsScreen = true;
            } else if (gameEnabled){
                leftXVel = -speed; //Left key during game
                previousKey = 1; //Move left
                attackOffset = -100;

                if (jumpVel == 0){ //If not jumping, set left running animation
                    tileIndex = 3;
                }
                leftPressed = true; //Left pressed, others false
                rightPressed = false; //Set false for other presses
                upPressed = false;
            }
        } else if (c == KeyEvent.VK_UP && !hasTopCollided && !jumpPressed && gameEnabled && !levelCompleted && !levelFailed && !menuScreen){ //JUMP, only jump once and stop velocity if collided with top
            jumpVel = 20; jumpPressed = true; upPressed = true;

            if (rightPressed) //Animations (RIGHT)
                tileIndex = 4;
            else if (leftPressed) //LEFT
                tileIndex = 5;
            else if (previousKey == 0) //Fix animation bug, use previous key if no left or right was pressed
                tileIndex = 4;
            else if (previousKey == 1){
                tileIndex = 5;
            }
        } else if (c == KeyEvent.VK_SPACE && !leftPressed && !rightPressed && !levelCompleted && !levelFailed && !menuScreen && !isAttacking && cooldown <= 0){
            isAttacking = true;
            assets.resetAttackGif();
            attack();
        } else if (c == KeyEvent.VK_X && (levelScreen || gameEnabled || settingsScreen)){
            if (gameEnabled){
                levelScreen = true;
                menuScreen = false;
                if (levelCompleted){
                    resetVariables();
                }
                if (level == 5 && musicEnabled){
                    stopMusic();
                    playMusic(0);
                }
            } else {
                levelScreen = false;
                menuScreen = true;
            }
            levelCompleted = false;
            levelFailed = false;
            gameEnabled = false;
            settingsScreen = false;

            uploadSavedData();
            resetVariables();
        } else if (c == KeyEvent.VK_C && settingsScreen){
            colliderEnabled = !colliderEnabled;
        } else if (c == KeyEvent.VK_D && settingsScreen){
            if (difficulty == 1){
                difficulty = 0;
                heartAmt = 3;
            } else {
                difficulty = 1;
                heartAmt = 1;
            }
        } else if (c == KeyEvent.VK_M && settingsScreen){
            if (musicEnabled){
                musicEnabled = false;
                stopMusic();
            } else {
                musicEnabled = true;
                playMusic(0);
            }
        } else if (c == KeyEvent.VK_ESCAPE){
            resetVariables();
            uploadSavedData();
            System.exit(0);
        }
    }
    public void keyReleased(KeyEvent e){
        int c = e.getKeyCode();
        if (c == KeyEvent.VK_SPACE && gameEnabled){
            isAttacking = false;
            enemyHit = false;
            cooldown = 60;
        }
        if (c == KeyEvent.VK_LEFT && gameEnabled){
            leftXVel = 0;
            tileIndex = 1;
            leftPressed = false;
        } else if (c == KeyEvent.VK_RIGHT && gameEnabled){
            rightXVel = 0;
            tileIndex = 0;
            rightPressed = false;
        } else if (c == KeyEvent.VK_R && !resetScreen && settingsScreen){
            resetScreen = true;
            Scanner scanner = new Scanner(System.in);
            System.out.println("Welcome to the ADMIN console");
            System.out.println("In order to reset your account, enter your key!");
            System.out.print("KEY: ");
            String key = scanner.nextLine();
            scanner.close();

            if (key.equals("726573657464617461")){
                resetData();
                uploadSavedData();
                resetScreen = false;
                System.out.println("SYSTEM: Account has been reset!");
            } else {
                System.out.println("Invalid key, your account has not been reset");
                resetScreen = false;
            }
        }
        hasDownCollided = false; //Set all collided to false
        hasLeftCollided = false;
        hasRightCollided = false;
        hasTopCollided = false;
    }
    public void keyTyped(KeyEvent e){}

    public void goToGame(){
        levelScreen = false;
        gameEnabled = true;
        score = 0;
    }
    public void uploadSavedData(){
        saveGame.storeScore = storeScore;
        saveGame.stars = starAmt;
        saveGame.grandStars = grandStarAmt;
        saveGame.difficulty = difficulty;
        saveGame.musicEnabled = musicEnabled;
        saveGame.colliderEnabled = colliderEnabled;
        saveGame.saveGame();
    }
    public void resetData(){
        Arrays.fill(storeScore, 100000);
        starAmt = 0; grandStarAmt = 0;
        musicEnabled = true;
        colliderEnabled = false;
        difficulty = 0;
        uploadSavedData();
    }
    public void resetVariables(){
        if (level == 5){
            fireBossSpeed = 1;
        } else
            fireBossSpeed = 0;

        x = 53; y = 300; fireBossX = -540;
        fireboss.x = fireBossX;
        xVel = 0; jumpVel = 0; rightXVel = 0; leftXVel = 0;
        offset = 0; attackOffset = 0;

        if (score < storeScore[level-1] && levelCompleted){ //Store high score
            storeScore[level-1] = score;
        }

        if (difficulty == 1){
            heartAmt = 1;
        } else
            heartAmt = 3;

        score = 0; cooldown = 0;
        tileIndex = 0; previousKey = 0;
        for (int i = 0; i < spirits.length; i++){
            spirits[i].resetSpiritLocation(level, i);
        }
    }
}